$(document).ready(() => {
    // $("button").click(function () {
    // 1 
    // $("*").hide();
    // 2
    // $(this).hide();
    // 3
    // $("p.intro").hide();
    // 4
    // $("p:first").hide();
    // 5
    // $("ul:first li:nth-child(3)").hide()
    // $("ul:eq(0) li:eq(2)").hide();   //Ejercicio 5
    // 6
    // $("ul li:nth-child(3)").hide()
    // 7
    // $("[href]").hide()
    // });
    // 8
    // $("#ventana").click(function () {
    //     $("a[target='_blank']").hide()
    // })
    // $("#enlace").click(function () {
    //     $("a[target!='_blank']").hide()

    // })

    // 11
    var bool = true;
    $("#tamaño").css("width", "800px");
    $("#tamaño").css("height", "70px");
    $("#tamaño").css("background-color", "white");
    $("#tamaño").dblclick(function () {
        bool = !bool
        if (bool) {
            $("#tamaño").css("width", "800px");
            $("#tamaño").css("height", "70px");
        } else {
            $("#tamaño").css("width", "250");
            $("#tamaño").css("height", "250px");
        }
    })
    // 12
    $("th").css("background-color", "blue")
    $("th").hover(function () {

        $(this).css("background-color", "red")
    }, function () {
        $(this).css("background-color", "blue")
    })
    // 13

    $("a.t").focus(function () {
        $("p.t").css("background-color", "red")

    })
    $("a.t").blur(function () {
        $("p.t").css("background-color", "yellow")

    })

    // 14
    $("#tooltip").prop("title", "tu titulo aqui")


})
